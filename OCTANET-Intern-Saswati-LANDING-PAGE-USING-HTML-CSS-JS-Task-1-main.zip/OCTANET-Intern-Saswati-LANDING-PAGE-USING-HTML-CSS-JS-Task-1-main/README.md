# OCTANET-Intern-Saswati-LANDING-PAGE-USING-HTML-CSS-JS-Task-1

DEMO VIDEO LINK : https://youtu.be/rXl0E_3xHx4
